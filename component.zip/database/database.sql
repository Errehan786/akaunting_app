CREATE DATABASE akaunting-app;
USE akaunting-app;