CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username char(255) NULL,
    email char(255) NULL,
    password char(255) NULL
);